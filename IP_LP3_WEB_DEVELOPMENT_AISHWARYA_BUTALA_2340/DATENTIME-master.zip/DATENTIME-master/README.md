# DATENTIME
Website displaying the current date and time of system. This is a personal website using full stack development which uses a REST API to tell system date and time by an API call. This is a LP3 assignment by cloud counselage.
