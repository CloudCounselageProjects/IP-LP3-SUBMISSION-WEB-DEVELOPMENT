import { Component, OnInit } from '@angular/core';
import { Date } from '../date';
import { DateService } from '../date.service'
import { Observable, throwError } from 'rxjs';

@Component({
  selector: 'app-dates',
  templateUrl: './dates.component.html',
  styleUrls: ['./dates.component.css'],
  providers: [DateService]
})
export class DatesComponent implements OnInit {
  dates: Date[];
  date: Date;
  //public date: Observable<Date[]>;
  //dates: string;

  constructor(private dateService: DateService) { }

  updateDates()
  {
    let newDate : Date = new Date();
    
    this.dateService.updateDates(newDate)
      .subscribe((res) => {
        console.log("Updated the date");
        this.dateService.getDates()
          .subscribe( date =>
          this.date = date);
      });
  }
  ngOnInit() {
    this.dateService.getDates()
      .subscribe( date =>
        this.date = date);
  }

  

}
