import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Date } from './date';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { Http, Headers } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class DateService {

  constructor(private http: Http) { }

  //retrieving date
  getDates()
  {
    return this.http.get('http://localhost:3000/api/dates')
      .pipe(map(res => res.json()));
  }

  updateDates(newDate)
  {
    const id = '5ecf4c0ae2621a5568dd9380';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'my-auth-token'
      })
    };
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/api/date/+id',newDate,{headers:headers})
      .pipe(map(res => res.json()));
  }
}
