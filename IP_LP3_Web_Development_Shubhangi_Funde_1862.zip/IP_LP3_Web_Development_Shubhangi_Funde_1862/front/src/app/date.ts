export class Date{
    date: string;
}
