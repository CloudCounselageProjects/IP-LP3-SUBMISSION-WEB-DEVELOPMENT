Install all dependencies then

For backend to start:
1.cd backend
2.nodemon server

For frontend to start:
1.yarn start or npm start 
