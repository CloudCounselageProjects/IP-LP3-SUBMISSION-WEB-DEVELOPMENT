# CloudCounselageAssignment
 
Lp3 Assignment:
Go to Task Logger
