## To RUN This app

1.First goto the backend directory and then install all the required package using cmd "npm install"(for server).<br />

2.Now on the backend dirctory open CMD and run the server using cmd "node server".<br/>

3.Now come to the main directory i.e "lp3".<br/>

4.open CMD and install all required react packages using cmd "npm install"(for frontend).<br/>

5.Now to launch app cmd "npm start".<br/>

### NOTE

It uses MATERIALIZE LIBRARY for styling ,therefore internet connection is required for proper clean display of components.<br/>
